Python 3.10.0 (tags/v3.10.0:b494f59, Oct  4 2021, 19:00:18) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
  from datetime import *
  from dateutil.relativedelta import *
  now = datetime.now()
  print(now)

  now = now + relativedelta(months=1, weeks=1, hour=10)

  print(now)